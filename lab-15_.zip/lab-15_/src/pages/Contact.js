import React from 'react';

function Contact() {
    return (
        <div style={{ padding: '20px' }}>
            <h1>Контакты</h1>
            <p>Телефон: +7 (999) 123-45-67</p>
        </div>
    );
}

export default Contact;