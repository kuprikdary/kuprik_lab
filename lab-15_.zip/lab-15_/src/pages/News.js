import React from 'react';

function News() {
    return (
        <div style={{ padding: '20px' }}>
            <h1>Новости</h1>
            <p>Пример текста новости.</p>
        </div>
    );
}

export default News;