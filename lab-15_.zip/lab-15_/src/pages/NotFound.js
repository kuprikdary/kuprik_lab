import React from 'react';

function NotFound() {
    return (
        <div style={{ padding: '20px' }}>
            <h1>404 — Страница не найдена</h1>
        </div>
    );
}

export default NotFound;