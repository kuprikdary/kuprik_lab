import React from 'react';

function About() {
    return (
        <div style={{ padding: '20px' }}>
            <h1>Южный федеральный университет</h1>
        </div>
    );
}

export default About;