import React from 'react';

function Aside() {
    return (
        <div style={{ textAlign: 'center', padding: '10px' }}>
            <p>Иванов Иван Иванович</p>
        </div>
    );
}

export default Aside;