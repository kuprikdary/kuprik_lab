import React from 'react';

function Section() {
    return (
        <div style={{ textAlign: 'center', padding: '10px' }}>
            <img src="https://via.placeholder.com/150" alt="Фото" />
        </div>
    );
}

export default Section;